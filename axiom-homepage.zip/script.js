const navItems = document.querySelectorAll(".nav-item");
const homePage = document.getElementById("home-page");
const otherPage = document.getElementById("other-page");
const pageTitle = document.getElementById("page-title");
const pageMessage = document.getElementById("page-message");
const searchForm = document.getElementById("search-form");
const searchInput = document.getElementById("search-input");
const toast = document.getElementById("toast");

const pageMessages = {
  games: "Your Games section can go here.",
  browser: "Your browser interface can go here.",
  media: "Your Media section can go here.",
  tools: "Your Tools section can go here.",
  account: "Your Account section can go here."
};

navItems.forEach((item) => {
  item.addEventListener("click", () => {
    navItems.forEach((nav) => nav.classList.remove("active"));
    item.classList.add("active");

    const page = item.dataset.page;

    if (page === "home") {
      otherPage.classList.remove("visible");
      homePage.classList.add("visible");
      return;
    }

    homePage.classList.remove("visible");
    otherPage.classList.add("visible");
    pageTitle.textContent = page.charAt(0).toUpperCase() + page.slice(1);
    pageMessage.textContent = pageMessages[page] || "This section is coming soon.";
  });
});

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");

  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2500);
}

searchForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const value = searchInput.value.trim();

  if (!value) {
    showToast("Type something first.");
    return;
  }

  // This GitHub Pages version does not pretend to proxy another website.
  // URLs are opened normally; search text uses Google search.
  let destination;

  if (/^https?:\/\//i.test(value)) {
    destination = value;
  } else if (/^[a-z0-9.-]+\.[a-z]{2,}(\/.*)?$/i.test(value)) {
    destination = "https://" + value;
  } else {
    destination = "https://www.google.com/search?q=" + encodeURIComponent(value);
  }

  window.open(destination, "_blank", "noopener,noreferrer");
});
